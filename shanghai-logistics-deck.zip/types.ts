export type DayId = 'guide' | number;

export interface Day {
  id: DayId;
  label: string;
  date: string;
  title: string;
  desc: string;
}

export interface TransportItem {
  type: 'van' | 'didi' | 'metro' | 'bus' | 'train' | 'walk';
  time: string;
  title: string;
  cn?: string;
  en?: string;
  searchStr?: string;
  addr?: string;
  wait?: string;
  timeEst: string;
  price: string;
  note?: string;
  line?: string;
  dir?: string;
  exit?: string;
  lat?: number;
  lng?: number;
}

export type DayDataMap = Record<number, TransportItem[]>;