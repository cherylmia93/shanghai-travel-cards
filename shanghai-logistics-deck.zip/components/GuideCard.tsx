import React from 'react';
import { CreditCard, Map, MessageCircle, Utensils } from 'lucide-react';

interface GuideAppProps {
  bgColor: string;
  icon: React.ReactNode;
  title: string;
  badge: string;
  points: string[];
}

const GuideAppCard: React.FC<GuideAppProps> = ({ bgColor, icon, title, badge, points }) => (
  <div className="flex gap-4 items-start p-4 rounded-xl border border-gray-100 bg-gray-50">
    <div className={`w-12 h-12 rounded-xl shadow-md shrink-0 flex items-center justify-center text-white ${bgColor}`}>
      {icon}
    </div>
    <div className="flex-1">
      <div className="flex justify-between items-center mb-1">
        <h3 className="font-bold text-slate-800">{title}</h3>
        <span className="text-[10px] font-bold bg-slate-200 text-slate-600 px-2 py-0.5 rounded uppercase tracking-wide">
          {badge}
        </span>
      </div>
      <ul className="text-sm space-y-1 text-slate-600">
        {points.map((p, i) => (
          <li key={i} className="flex gap-2">
            <span className="opacity-50">•</span>
            <span dangerouslySetInnerHTML={{ __html: p }} />
          </li>
        ))}
      </ul>
    </div>
  </div>
);

export const GuideView: React.FC = () => {
  return (
    <div className="bg-white rounded-2xl p-6 shadow-lg border-2 border-[#D97706]/20">
      <h2 className="text-2xl font-black text-[#5C4033] mb-6 flex items-center gap-2">
        <span className="text-3xl">📱</span> Essential Apps
      </h2>
      <div className="space-y-4">
        <GuideAppCard
          bgColor="bg-[#1677FF]"
          icon={<div className="font-bold text-lg">支</div>}
          title="Alipay (Zhifubao)"
          badge="PAY • METRO • TAXI"
          points={[
            '<strong>Setup:</strong> Link your foreign Visa/Mastercard. Works for 99% of vendors.',
            '<strong>Metro:</strong> Click "Transport" ➔ "Metro". Scan QR at turnstile.',
            '<strong>Ride Hailing:</strong> Click "Transport" ➔ "Taxi". Paste Chinese addresses from this deck.'
          ]}
        />
        <GuideAppCard
          bgColor="bg-white border-2 border-blue-400 text-blue-500"
          icon={<Map size={24} />}
          title="Amap (Gaode Ditu)"
          badge="MAPS"
          points={[
            '<strong>Why:</strong> Google Maps is blocked. Amap is accurate.',
            '<strong>Nav:</strong> Copy addresses from deck ➔ Paste ➔ Follow blue arrow.',
            '<strong>3D:</strong> Shows 3D buildings to find entrances easily.'
          ]}
        />
        <GuideAppCard
          bgColor="bg-[#07C160]"
          icon={<MessageCircle size={24} />}
          title="WeChat (Weixin)"
          badge="CHAT • ORDERING"
          points={[
            '<strong>Dining:</strong> Scan table QR codes to order food (digital menu).',
            '<strong>Translate:</strong> Long-press Chinese messages to translate to English.'
          ]}
        />
        <GuideAppCard
          bgColor="bg-[#FF6600]"
          icon={<Utensils size={24} />}
          title="Dianping"
          badge="REVIEWS • QUEUE"
          points={[
            '<strong>Queue:</strong> Use "排队" feature to queue remotely.',
            '<strong>Menu:</strong> Show food photos to waiters to order visually.'
          ]}
        />
      </div>
    </div>
  );
};
