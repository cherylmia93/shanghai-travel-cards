import React, { useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import L from 'leaflet';
import { TransportItem } from '../types';
import { Car, Train, MapPin, Bus, PersonStanding } from 'lucide-react';
import { renderToString } from 'react-dom/server';

interface MapViewProps {
  items: TransportItem[];
}

// Helper to fit bounds
const BoundsFitter: React.FC<{ items: TransportItem[] }> = ({ items }) => {
  const map = useMap();
  const points = items.filter(i => i.lat && i.lng).map(i => [i.lat!, i.lng!] as [number, number]);
  
  React.useEffect(() => {
    if (points.length > 0) {
      const bounds = L.latLngBounds(points);
      map.fitBounds(bounds, { padding: [50, 50] });
    }
  }, [items, map]);

  return null;
};

// Create custom icons from Lucide icons
const createIcon = (type: string) => {
  let IconComponent = MapPin;
  let color = '#D97706'; // default orange

  if (type === 'didi' || type === 'van') {
    IconComponent = Car;
    color = '#D97706';
  } else if (type === 'metro' || type === 'train') {
    IconComponent = Train;
    color = '#3B82F6'; // blue
  } else if (type === 'bus') {
    IconComponent = Bus;
    color = '#10B981'; // green
  } else if (type === 'walk') {
    IconComponent = PersonStanding;
    color = '#64748B'; // slate
  }

  const iconHtml = renderToString(
    <div className={`w-8 h-8 rounded-full border-2 border-white shadow-lg flex items-center justify-center`} style={{ backgroundColor: color }}>
      <IconComponent size={16} color="white" strokeWidth={2.5} />
    </div>
  );

  return L.divIcon({
    html: iconHtml,
    className: 'custom-leaflet-icon', // prevent default styles
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  });
};

const MapView: React.FC<MapViewProps> = ({ items }) => {
  const validItems = useMemo(() => items.filter(i => i.lat && i.lng), [items]);
  const positions = validItems.map(i => [i.lat!, i.lng!] as [number, number]);
  
  // Default to Shanghai Center if no points
  const center: [number, number] = positions.length > 0 ? positions[0] : [31.2304, 121.4737];

  return (
    <div className="h-[500px] w-full rounded-xl overflow-hidden shadow-lg border-2 border-slate-200">
      <MapContainer center={center} zoom={12} scrollWheelZoom={false}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png"
        />
        
        <BoundsFitter items={validItems} />

        <Polyline 
            positions={positions} 
            pathOptions={{ color: '#D97706', dashArray: '10, 10', opacity: 0.6, weight: 4 }} 
        />

        {validItems.map((item, idx) => (
          <Marker 
            key={idx} 
            position={[item.lat!, item.lng!]} 
            icon={createIcon(item.type)}
          >
            <Popup className="font-sans">
                <div className="text-sm">
                    <div className="font-bold text-[#8B4513] mb-1">{item.time} - {item.title}</div>
                    <div className="font-bold text-lg mb-1">{item.cn}</div>
                    <div className="text-slate-500 text-xs mb-2">{item.en}</div>
                    <div className="bg-slate-100 text-slate-600 px-2 py-1 rounded text-xs font-mono inline-block">
                        {item.type.toUpperCase()} • {item.price}
                    </div>
                </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
};

export default MapView;
