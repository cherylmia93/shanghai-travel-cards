import { Day, DayDataMap } from './types';

export const DAYS: Day[] = [
  { id: 'guide', label: "📘 GUIDE", date: "READ ME", title: "How to Use", desc: "Essential Apps & Navigation Tips" },
  { id: 0, label: "Day 0", date: "Dec 21", title: "Arrival Logistics", desc: "Airport Pickup & Check-in" },
  { id: 1, label: "Day 1", date: "Dec 22", title: "French Concession", desc: "Tianzifang, Anfu Rd & Trendy Shopping" },
  { id: 2, label: "Day 2", date: "Dec 23", title: "Disneyland", desc: "Magic & Fireworks" },
  { id: 3, label: "Day 3", date: "Dec 24", title: "Nanjing Rd", desc: "Christmas Eve Classic & Yu Garden" },
  { id: 4, label: "Day 4", date: "Dec 25", title: "Christmas", desc: "Coffee, Crab & River Cruise" },
  { id: 5, label: "Day 5", date: "Dec 26", title: "Futuristic", desc: "1000 Trees, Gundam & Sci-Fi Dining" },
  { id: 6, label: "Day 6", date: "Dec 27", title: "Water Town", desc: "Old Shanghai Vibes & Film Park" },
  { id: 7, label: "Day 7", date: "Dec 28", title: "Safari", desc: "Wild Animals & Comfort Food" },
  { id: 8, label: "Day 8", date: "Dec 29", title: "Hangzhou", desc: "Matcha Lake & Farm Feast Day Trip" },
  { id: 9, label: "Day 9", date: "Dec 30", title: "Imperial", desc: "Hanfu Banquet, Wukang & History" },
  { id: 10, label: "Day 10", date: "Dec 31", title: "Departure", desc: "Chill Morning & Flight Home" },
];

export const DAY_DATA: DayDataMap = {
  0: [
    { type: 'van', time: '22:30', title: 'AIRPORT PICKUP', cn: '虹口名苑', en: 'Hongkou Mingyuan', searchStr: '虹口名苑 西藏南路1501弄', addr: '西藏南路1501弄', wait: 'Arrivals Hall Barrier (Inside)', timeEst: '50m', price: 'Pre-booked', note: 'Driver will hold a name sign. Do not go outside.', lat: 31.216, lng: 121.480 }
  ],
  1: [
    { type: 'didi', time: '09:30', title: 'START', cn: '田子坊(1号门)', en: 'Tianzifang (Gate 1)', searchStr: '田子坊-1号门', addr: '泰康路210弄', wait: 'Lane 1501 Curbside', timeEst: '15m', price: '~¥25', note: 'Gate 1 is the main entrance on Taikang Rd.', lat: 31.209, lng: 121.469 },
    { type: 'didi', time: '11:00', title: 'LUNCH', cn: '喜粤8号(汝南街店)', en: 'Canton 8', searchStr: '喜粤8号(汝南街店) 汝南街63号', addr: '汝南街63号', wait: 'Tianzifang Gate 1', timeEst: '15m', price: '~¥20', lat: 31.206, lng: 121.474 },
    { type: 'didi', time: '13:00', title: 'SHOPPING', cn: 'Sunflour(安福路店)', en: 'Sunflour Bakery', searchStr: 'Sunflour(安福路店)', addr: '安福路322号', wait: 'Restaurant Curbside', timeEst: '20m', price: '~¥35', note: 'Seniors stay here. Young adults explore.', lat: 31.215, lng: 121.442 },
    { type: 'didi', time: '18:00', title: 'DINNER', cn: '蟹三宝(南京西路店)', en: 'Xie San Bao', searchStr: '蟹三宝(南京西路店)', addr: '南汇路74号', wait: 'Sunflour Curbside', timeEst: '20m', price: '~¥25', note: 'Address is Nanhui Rd, but listed as Nanjing West Rd Branch.', lat: 31.229, lng: 121.459 },
    { type: 'didi', time: '20:00', title: 'HOME', cn: '虹口名苑', en: 'Hongkou Mingyuan', searchStr: '虹口名苑 西藏南路1501弄', addr: '西藏南路1501弄', wait: 'Outside Restaurant', timeEst: '25m', price: '~¥30', lat: 31.216, lng: 121.480 }
  ],
  2: [
    { type: 'metro', time: '07:30', title: 'TO DISNEY', line: 'Line 11', dir: 'Disney Resort', exit: 'Exit 1', timeEst: '50m', price: '~¥6', note: 'Transfer at Oriental Sports Center.', lat: 31.141, lng: 121.662 },
    { type: 'didi', time: '21:15', title: 'RETURN', cn: '虹口名苑', en: 'Hongkou Mingyuan', searchStr: '虹口名苑 西藏南路1501弄', addr: '西藏南路1501弄', wait: 'West Public Transportation Hub', timeEst: '45m', price: '~¥150', note: 'Follow signs to "West PTH" / Taxi. Do not wait at main gate.', lat: 31.216, lng: 121.480 }
  ],
  3: [
    { type: 'metro', time: '09:15', title: 'TO NANJING RD', line: 'Line 8', dir: 'Shiguang Rd', exit: 'Exit 19', timeEst: '15m', price: '~¥3', note: 'Exit 19 leads into New World City Basement.', lat: 31.235, lng: 121.475 },
    { type: 'didi', time: '13:45', title: 'TO YU GARDEN', cn: '豫园商城-2号门', en: 'Yu Garden Gate 2', searchStr: '豫园商城-2号门', addr: '福佑路', wait: 'Huanghe Road', timeEst: '20m', price: '~¥30', note: 'Call from Huanghe Rd (quieter street).' , lat: 31.227, lng: 121.492 },
    { type: 'didi', time: '19:30', title: 'HOME', cn: '虹口名苑', en: 'Hongkou Mingyuan', searchStr: '虹口名苑 西藏南路1501弄', addr: '西藏南路1501弄', wait: 'Fuyou Road (Gate 2)', timeEst: '20m', price: '~¥25', lat: 31.216, lng: 121.480 }
  ],
  4: [
    { type: 'didi', time: '09:30', title: 'COFFEE', cn: '星巴克臻选上海烘焙工坊', en: 'Starbucks Reserve', searchStr: '星巴克臻选上海烘焙工坊', addr: '南京西路789号', wait: 'Lane 1501 Curbside', timeEst: '20m', price: '~¥25', lat: 31.230, lng: 121.456 },
    { type: 'didi', time: '12:00', title: 'LUNCH', cn: '全聚德(淮海中路店)', en: 'Quanjude Duck', searchStr: '全聚德(淮海中路店)', addr: '淮海中路780号', wait: 'Shimen 1st Road (Side Door)', timeEst: '15m', price: '~¥20', note: 'Exit Starbucks via SIDE door to avoid traffic.', lat: 31.220, lng: 121.464 },
    { type: 'didi', time: '14:00', title: 'PHOTO', cn: '北外滩滨江绿地', en: 'North Bund', searchStr: '北外滩滨江绿地', addr: '东大名路500号对面', wait: 'Quanjude Lobby', timeEst: '20m', price: '~¥30', lat: 31.250, lng: 121.495 },
    { type: 'didi', time: '15:30', title: 'MARKET', cn: '圆明园路步行街', en: 'Rockbund', searchStr: '圆明园路步行街', addr: '北京东路', wait: 'North Bund Roadside', timeEst: '10m', price: '~¥15', lat: 31.243, lng: 121.490 },
    { type: 'walk', time: '17:30', title: 'DINNER', cn: '海底捞(外滩店)', en: 'Haidilao', addr: '南京东路123号', wait: 'Walk', timeEst: '8m', price: '0', note: 'Walk South on Yuanmingyuan Rd.', lat: 31.240, lng: 121.491 },
    { type: 'didi', time: '19:30', title: 'CRUISE', cn: '十六铺码头', en: 'Shiliupu Pier', searchStr: '十六铺码头', addr: '中山东二路551号', wait: 'Bund Central Mall', timeEst: '10m', price: '~¥15', lat: 31.225, lng: 121.498 },
    { type: 'didi', time: '21:30', title: 'HOME', cn: '虹口名苑', en: 'Hongkou Mingyuan', searchStr: '虹口名苑 西藏南路1501弄', addr: '西藏南路1501弄', wait: 'BFC North District Drop-off', timeEst: '20m', price: '~¥25', note: 'Walk to BFC Mall driveway. Do NOT wait at Pier curbside.', lat: 31.216, lng: 121.480 }
  ],
  5: [
    { type: 'didi', time: '09:00', title: '1000 TREES', cn: '昌化路桥', en: 'Changhua Bridge', searchStr: '昌化路桥', addr: '莫干山路口', wait: 'Lane 1501 Curbside', timeEst: '25m', price: '~¥35', note: 'Drop on the bridge for the best photo view.', lat: 31.246, lng: 121.446 },
    { type: 'didi', time: '10:30', title: 'LUNCH', cn: '3号仓库(新世界城店)', en: 'No. 3 Warehouse', searchStr: '3号仓库(新世界城店)', addr: '南京西路2-68号', wait: '1000 Trees West Gate', timeEst: '15m', price: '~¥25', lat: 31.235, lng: 121.470 },
    { type: 'metro', time: '13:00', title: 'SKYWALK', line: 'Line 2', dir: 'Pudong Airport', exit: 'Exit 2', timeEst: '15m', price: '~¥3', note: 'Exit 2 leads directly to Bridge Escalator.', lat: 31.237, lng: 121.499 },
    { type: 'didi', time: '14:30', title: 'GUNDAM', cn: '啦啦宝都(上海金桥店)', en: 'LaLaport', searchStr: '啦啦宝都(上海金桥店)', addr: '新金桥路738号', wait: 'Grand Hyatt Lobby', timeEst: '25m', price: '~¥40', lat: 31.261, lng: 121.588 },
    { type: 'didi', time: '17:00', title: 'TO METRO', cn: '台儿庄路(地铁站)', en: 'Tai\'erzhuang Rd', searchStr: '台儿庄路(地铁站)', addr: '9号线', wait: 'LaLaport Main Entrance', timeEst: '5m', price: '~¥15', note: 'Short ride to avoid rush hour traffic.', lat: 31.264, lng: 121.590 },
    { type: 'metro', time: '17:15', title: 'DIRECT TRAIN', line: 'Line 9', dir: 'Songjiang', exit: 'Jiashan Rd Exit 2', timeEst: '40m', price: '~¥5', note: 'Relaxing 40 min ride. No transfers.', lat: 31.202, lng: 121.458 },
    { type: 'walk', time: '18:00', title: 'DINNER', cn: '人和馆(肇嘉浜路店)', en: 'Ren He Guan', addr: '肇嘉浜路407号', wait: 'Exit 2', timeEst: '5m', price: '0', note: 'Walk 300m straight.', lat: 31.202, lng: 121.455 },
    { type: 'didi', time: '20:00', title: 'HOME', cn: '虹口名苑', en: 'Hongkou Mingyuan', searchStr: '虹口名苑 西藏南路1501弄', addr: '西藏南路1501弄', wait: 'Restaurant Curbside', timeEst: '15m', price: '~¥20', lat: 31.216, lng: 121.480 }
  ],
  6: [
    { type: 'metro', time: '08:00', title: 'MEETING PT', line: 'Line 8', dir: 'Shiguang Rd', exit: 'See Ticket', timeEst: '15m', price: '~¥3', note: 'Check bus confirmation for specific Exit.', lat: 31.235, lng: 121.475 },
    { type: 'bus', time: '08:30', title: 'TOUR BUS', cn: 'Bus Tour', en: 'Film Park', addr: 'People\'s Square', wait: 'Designated Spot', timeEst: '50m', price: 'Included', lat: 31.026, lng: 121.300 },
    { type: 'walk', time: '18:30', title: 'DINNER', cn: '很久以前羊肉串(云南南路店)', en: 'Henjiu Yiqian', addr: '云南南路180号', wait: 'Walk', timeEst: '10m', price: '0', lat: 31.230, lng: 121.480 },
    { type: 'didi', time: '20:30', title: 'HOME', cn: '虹口名苑', en: 'Hongkou Mingyuan', searchStr: '虹口名苑 西藏南路1501弄', addr: '西藏南路1501弄', wait: 'Restaurant Curbside', timeEst: '15m', price: '~¥20', lat: 31.216, lng: 121.480 }
  ],
  7: [
    { type: 'didi', time: '08:00', title: 'SAFARI', cn: '上海野生动物园', en: 'Wild Animal Park', searchStr: '上海野生动物园', addr: '浦东新区', wait: 'Lane 1501 Curbside', timeEst: '1.5h', price: '~¥120', note: 'Long ride.', lat: 31.056, lng: 121.716 },
    { type: 'didi', time: '16:30', title: 'HOME', cn: '虹口名苑', en: 'Hongkou Mingyuan', searchStr: '虹口名苑 西藏南路1501弄', addr: '西藏南路1501弄', wait: 'Main Parking Lot (Taxi Zone)', timeEst: '1.5h', price: '~¥120', note: 'Go to designated Taxi Zone.', lat: 31.216, lng: 121.480 }
  ],
  8: [
    { type: 'didi', time: '09:00', title: 'STATION', cn: '上海虹桥站-出发层', en: 'Hongqiao Station', searchStr: '上海虹桥站-出发层', addr: 'South/North Drop-off', wait: 'Lane 1501 Curbside', timeEst: '45m', price: '~¥70', note: 'Go to "Departures" level.', lat: 31.196, lng: 121.316 },
    { type: 'train', time: '10:00', title: 'TRAIN G239', cn: '杭州东站', en: 'Hangzhou East', addr: 'G Train', wait: 'Station Gates', timeEst: '45m', price: 'Booked', note: 'Scan Passport at Manual Lane.', lat: 30.291, lng: 120.213 },
    { type: 'didi', time: '11:00', title: 'LAKE', cn: '青山湖水上森林', en: 'Qingshan Lake', searchStr: '青山湖水上森林', addr: '临安区', wait: 'Hangzhou East P1 Parking', timeEst: '1.5h', price: '~¥100', note: 'Follow signs to "Online Car Hailing" (网约车).', lat: 30.250, lng: 119.750 },
    { type: 'didi', time: '15:15', title: 'RETURN RIDE', cn: '杭州东站-出发层', en: 'Hangzhou East Station', searchStr: '杭州东站-出发层', addr: 'Departures', wait: 'Lake Entrance', timeEst: '1.5h', price: '~¥100', note: 'Aim to arrive by 17:00.', lat: 30.291, lng: 120.213 },
    { type: 'train', time: '17:40', title: 'TRAIN G7590', cn: '上海虹桥站', en: 'Shanghai Hongqiao', addr: 'Shanghai', wait: 'Ticket Gate', timeEst: '59m', price: 'Booked', lat: 31.196, lng: 121.316 },
    { type: 'didi', time: '19:00', title: 'HOME', cn: '虹口名苑', en: 'Hongkou Mingyuan', searchStr: '虹口名苑 西藏南路1501弄', addr: '西藏南路1501弄', wait: 'P10 Parking Garage', timeEst: '45m', price: '~¥70', note: 'Follow signs to P10 / Ride Hailing.', lat: 31.216, lng: 121.480 }
  ],
  9: [
    { type: 'metro', time: '08:30', title: 'LUNCH', line: 'Line 8 -> 9', dir: 'Songjiang', exit: 'Exit 2', timeEst: '1h', price: '~¥6', note: 'To Songjiang University Town.', lat: 31.050, lng: 121.230 },
    { type: 'didi', time: '14:30', title: 'PHOTO', cn: '宋庆龄故居', en: 'Wukang Mansion', searchStr: '宋庆龄故居', addr: '淮海中路1843号', wait: 'Restaurant Curbside', timeEst: '1h', price: '~¥100', note: 'Drop here for best view of Mansion.', lat: 31.204, lng: 121.437 },
    { type: 'didi', time: '16:00', title: 'SHOPPING', cn: '新天地', en: 'Xintiandi', searchStr: '新天地', addr: '马当路', wait: 'Wukang Mansion', timeEst: '20m', price: '~¥25', lat: 31.221, lng: 121.474 },
    { type: 'didi', time: '20:30', title: 'HOME', cn: '虹口名苑', en: 'Hongkou Mingyuan', searchStr: '虹口名苑 西藏南路1501弄', addr: '西藏南路1501弄', wait: 'Fuyou Road', timeEst: '20m', price: '~¥20', lat: 31.216, lng: 121.480 }
  ],
  10: [
    { type: 'didi', time: '11:00', title: 'LUGGAGE', cn: '龙阳路(地铁站)', en: 'Longyang Rd Station', searchStr: '龙阳路(地铁站)', addr: '磁悬浮', wait: 'Lane 1501 Curbside', timeEst: '20m', price: '~¥30', lat: 31.204, lng: 121.554 },
    { type: 'didi', time: '11:30', title: 'LUNCH', cn: '费大厨辣椒炒肉(南京东路悦荟广场店)', en: 'Fei Da Chu (Mosaic Mall)', searchStr: '费大厨辣椒炒肉(南京东路悦荟广场店)', addr: '南京东路353号', wait: 'Longyang Rd', timeEst: '25m', price: '~¥30', note: 'Queue on Dianping!', lat: 31.238, lng: 121.482 },
    { type: 'walk', time: '13:30', title: 'STROLL', cn: '南京东路步行街', en: 'Nanjing Rd Stroll', addr: 'Walking Street', wait: 'Mosaic Mall', timeEst: '1h', price: '0', note: 'Shop & Explore.', lat: 31.238, lng: 121.482 },
    { type: 'didi', time: '15:00', title: 'LAST STOP', cn: 'EKA·天物', en: 'EKA Tianwu', searchStr: 'EKA·天物', addr: '金桥路535号', wait: 'Nanjing East Rd', timeEst: '30m', price: '~¥40', lat: 31.258, lng: 121.583 },
    { type: 'didi', time: '19:00', title: 'RETRIEVE', cn: '龙阳路(地铁站)', en: 'Longyang Rd Station', searchStr: '龙阳路(地铁站)', addr: '磁悬浮', wait: 'EKA Entrance', timeEst: '30m', price: '~¥30', lat: 31.204, lng: 121.554 },
    { type: 'train', time: '19:30', title: 'AIRPORT', cn: '浦东国际机场T1航站楼', en: 'PVG Airport T1', addr: 'Terminal 1', wait: 'Maglev Platform', timeEst: '8m', price: '¥50', note: 'Maglev Train.', lat: 31.144, lng: 121.808 }
  ]
};