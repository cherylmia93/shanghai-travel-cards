import React from 'react';
import { Copy, MapPin, Clock, Info, Car, Train, Bus, PersonStanding } from 'lucide-react';
import { TransportItem } from '../types';

interface TransportCardProps {
  item: TransportItem;
  onCopy: (text: string) => void;
}

const TransportCard: React.FC<TransportCardProps> = ({ item, onCopy }) => {
  const { type, time, title, cn, en, searchStr, addr, wait, timeEst, price, note } = item;

  let Icon = Car;
  if (type === 'bus') Icon = Bus;
  if (type === 'train') Icon = Train;
  if (type === 'walk') Icon = PersonStanding;

  const iconLabel = type === 'didi' ? 'DiDi / Taxi' : type.toUpperCase();
  const iconColor = (type === 'didi' || type === 'van') 
    ? 'bg-[#D97706]' 
    : (type === 'train' || type === 'bus' ? 'bg-blue-500' : 'bg-slate-500');

  const textToCopy = searchStr || cn || '';

  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-lg border border-gray-100 hover:translate-y-[-2px] transition-transform duration-200">
      
      {/* 1. Top Logistics Bar */}
      <div className="bg-slate-50 p-3 flex justify-between items-center border-b border-gray-100">
        <div className="flex items-center gap-2">
          <span className="font-black text-xl text-[#8B4513]">{time}</span>
          <div className={`${iconColor} text-white flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase`}>
             <Icon size={10} strokeWidth={3} /> {iconLabel}
          </div>
        </div>
        <div className="text-right flex flex-col items-end">
          <div className="text-xs font-bold text-slate-500 flex items-center gap-1">
            <Clock size={12} /> {timeEst}
          </div>
          <div className="text-xs font-bold text-[#D97706] bg-orange-50 px-1.5 rounded mt-0.5">
            {price}
          </div>
        </div>
      </div>

      {/* 2. Middle Context */}
      <div className="p-4 pb-2">
        <h3 className="font-bold text-lg text-slate-800 leading-tight mb-1">{title}: <span className="text-slate-600 font-medium">{en}</span></h3>
        <div className="text-sm text-slate-500 mb-2 flex items-start gap-1">
          <MapPin size={16} className="shrink-0 mt-0.5" /> 
          <span><strong>Wait:</strong> {wait}</span>
        </div>
        {note && (
          <div className="text-xs bg-slate-50 text-slate-600 p-2 rounded border border-slate-100 flex gap-1 italic">
             <Info size={14} className="shrink-0 text-[#D97706]" /> {note}
          </div>
        )}
      </div>

      {/* 3. Bottom Action (Driver Card) */}
      {cn && (
        <button 
          onClick={() => onCopy(textToCopy)}
          className="w-full text-left bg-[#2A2A2A] p-4 cursor-pointer hover:bg-[#333] transition-colors relative group mt-2"
        >
          <div className="absolute top-3 right-3 text-[#D97706] text-[10px] font-bold uppercase tracking-wider opacity-70 group-hover:opacity-100 flex items-center gap-1">
            <Copy size={12} /> Tap to Copy for DiDi
          </div>
          <div className="text-[10px] text-gray-400 uppercase font-bold tracking-widest mb-1">
            Destination
          </div>
          <h2 className="text-2xl font-bold text-[#D97706] leading-tight mb-1 break-words select-all">
            {cn}
          </h2>
          <div className="text-gray-400 text-xs font-mono select-all">
            {addr ? `📍 ${addr}` : ''}
          </div>
        </button>
      )}
    </div>
  );
};

export default TransportCard;
