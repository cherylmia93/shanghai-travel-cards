import React from 'react';
import { Day, DayId } from '../types';

interface TabButtonProps {
  day: Day;
  isActive: boolean;
  onClick: (id: DayId) => void;
}

const TabButton: React.FC<TabButtonProps> = ({ day, isActive, onClick }) => {
  const baseClasses = "flex-shrink-0 px-4 py-2 rounded-xl text-xs font-bold border-2 transition-all duration-200 ease-in-out cursor-pointer select-none";
  const activeClasses = "bg-[#D97706] text-white border-[#D97706] shadow-md scale-105";
  const inactiveClasses = "bg-white text-[#8B4513] border-transparent hover:border-[#D97706]/30";

  return (
    <button
      onClick={() => onClick(day.id)}
      className={`${baseClasses} ${isActive ? activeClasses : inactiveClasses}`}
    >
      <div className="opacity-80 uppercase text-[10px] mb-0.5">{day.date}</div>
      <div>{day.label}</div>
    </button>
  );
};

export default TabButton;
