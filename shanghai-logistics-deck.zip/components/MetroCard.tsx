import React from 'react';
import { Clock, Info, TrainFront, Waypoints } from 'lucide-react';
import { TransportItem } from '../types';

interface MetroCardProps {
  item: TransportItem;
}

const MetroCard: React.FC<MetroCardProps> = ({ item }) => {
  const { time, title, line, dir, exit, timeEst, price, note } = item;
  
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-sm border-l-8 border-[#D97706] flex flex-col hover:translate-y-[-2px] transition-transform duration-200">
      
      {/* Top Logistics */}
      <div className="p-3 bg-slate-50 border-b border-gray-100 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <span className="font-black text-xl text-[#8B4513]">{time}</span>
          <div className="bg-green-600 text-white flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">
             <TrainFront size={10} strokeWidth={3} /> METRO
          </div>
        </div>
        <div className="text-right">
          <div className="text-xs font-bold text-slate-500 flex items-center gap-1 justify-end">
            <Clock size={12} /> {timeEst}
          </div>
          <div className="text-xs font-bold text-[#D97706] bg-orange-50 px-1.5 rounded mt-0.5">{price}</div>
        </div>
      </div>

      {/* Main Info */}
      <div className="p-4">
        <h3 className="font-bold text-lg text-slate-800 mb-3">{title}</h3>
        
        <div className="grid grid-cols-2 gap-4 text-sm mb-3">
          <div>
            <div className="text-[10px] text-slate-400 uppercase font-bold flex items-center gap-1 mb-0.5">
                <Waypoints size={12} /> Line & Direction
            </div>
            <div className="font-bold text-slate-800 leading-snug">
              {line} <span className="font-normal text-slate-500 block text-xs">to {dir}</span>
            </div>
          </div>
          <div>
            <div className="text-[10px] text-slate-400 uppercase font-bold mb-0.5">Target Exit</div>
            <div className="font-bold text-[#D97706] text-lg flex items-center gap-1">📍 {exit}</div>
          </div>
        </div>

        {note && (
           <div className="text-xs text-slate-500 italic border-t border-slate-100 pt-2 flex items-start gap-1">
             <Info size={14} className="shrink-0 mt-0.5" /> {note}
           </div>
        )}
      </div>
    </div>
  );
};

export default MetroCard;
