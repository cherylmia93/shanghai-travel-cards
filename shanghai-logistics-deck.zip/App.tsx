import React, { useState } from 'react';
import { DAY_DATA, DAYS } from './constants';
import { DayId } from './types';
import TabButton from './components/TabButton';
import TransportCard from './components/TransportCard';
import MetroCard from './components/MetroCard';
import { GuideView } from './components/GuideCard';
import Toast from './components/Toast';
import MapView from './components/MapView';
import { List, Map as MapIcon } from 'lucide-react';

const App: React.FC = () => {
  const [activeTabId, setActiveTabId] = useState<DayId>('guide');
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const activeDay = DAYS.find(d => d.id === activeTabId);
  const items = typeof activeTabId === 'number' ? DAY_DATA[activeTabId] : [];

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setToastMessage(text);
    }).catch(err => {
      console.error('Failed to copy', err);
      // Fallback alert for older browsers or if clipboard fails
      alert('Copied: ' + text);
    });
  };

  return (
    <div className="max-w-3xl mx-auto p-4 min-h-screen pb-12">
      
      {/* Header */}
      <div className="mb-6 text-center pt-2">
        <h1 className="text-3xl md:text-5xl font-black text-[#8B4513] uppercase tracking-tight mb-2">
          Shanghai <span className="text-[#D97706]">Logistics</span>
        </h1>
        <p className="text-xs font-bold tracking-widest text-[#5C4033] uppercase">Master Transport Deck</p>
      </div>

      {/* Tabs */}
      <div className="flex overflow-x-auto gap-2 pb-4 mb-4 no-scrollbar items-center">
        {DAYS.map(day => (
          <TabButton
            key={day.id}
            day={day}
            isActive={day.id === activeTabId}
            onClick={(id) => {
                setActiveTabId(id);
                // Reset to list view if switching to Guide
                if (id === 'guide') setViewMode('list');
            }}
          />
        ))}
        {/* Spacer for right padding in scroll view */}
        <div className="w-2 flex-shrink-0" />
      </div>

      {/* View Toggle */}
      {activeTabId !== 'guide' && (
        <div className="flex justify-center mb-6">
            <div className="bg-slate-200 p-1 rounded-lg flex gap-1 shadow-inner">
                <button 
                    onClick={() => setViewMode('list')}
                    className={`flex items-center gap-2 px-4 py-1.5 rounded-md text-sm font-bold transition-all ${viewMode === 'list' ? 'bg-white text-[#D97706] shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    <List size={16} strokeWidth={2.5} /> List
                </button>
                <button 
                    onClick={() => setViewMode('map')}
                    className={`flex items-center gap-2 px-4 py-1.5 rounded-md text-sm font-bold transition-all ${viewMode === 'map' ? 'bg-white text-[#D97706] shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    <MapIcon size={16} strokeWidth={2.5} /> Map
                </button>
            </div>
        </div>
      )}

      {/* Content Area */}
      <div className="space-y-6 animate-in fade-in duration-500">
        
        {activeTabId === 'guide' ? (
          <GuideView />
        ) : (
          <>
            {/* Day Header */}
            {activeDay && (
              <div className="mb-6 bg-white rounded-xl p-4 border-l-4 border-[#D97706] shadow-sm flex flex-col justify-center">
                <h2 className="text-xl font-black text-[#5C4033] mb-1">{activeDay.title}</h2>
                <p className="text-sm text-slate-500">{activeDay.desc}</p>
              </div>
            )}

            {/* List vs Map Render */}
            {viewMode === 'map' ? (
                <MapView items={items} />
            ) : (
                items && items.length > 0 ? (
                    items.map((item, index) => (
                      <React.Fragment key={index}>
                        {item.type === 'metro' ? (
                          <MetroCard item={item} />
                        ) : (
                          <TransportCard item={item} onCopy={handleCopy} />
                        )}
                      </React.Fragment>
                    ))
                ) : (
                   <div className="text-center text-slate-400 py-10 font-bold">No itinerary data for this day.</div>
                )
            )}
          </>
        )}
      </div>

      {toastMessage && (
        <Toast message={toastMessage} onClose={() => setToastMessage(null)} />
      )}

    </div>
  );
};

export default App;
