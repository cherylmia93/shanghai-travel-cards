import React, { useEffect } from 'react';
import { CheckCircle2 } from 'lucide-react';

interface ToastProps {
  message: string;
  onClose: () => void;
}

const Toast: React.FC<ToastProps> = ({ message, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(onClose, 2500);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-bottom-4 duration-300">
      <div className="bg-[#2A2A2A] text-white px-6 py-3 rounded-full shadow-2xl flex items-center gap-3 border border-gray-700">
        <CheckCircle2 className="text-[#D97706]" size={20} />
        <div>
            <p className="font-bold text-sm">Copied to clipboard!</p>
            <p className="text-[10px] text-gray-400 truncate max-w-[200px]">{message}</p>
        </div>
      </div>
    </div>
  );
};

export default Toast;
